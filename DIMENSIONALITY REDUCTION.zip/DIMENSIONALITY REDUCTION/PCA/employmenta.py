# -*- coding: utf-8 -*-
"""
Created on Thu Aug 30 13:27:04 2018

@author: Sir Scoffield
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
