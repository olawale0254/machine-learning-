# -*- coding: utf-8 -*-
"""
Created on Fri Aug 17 17:42:40 2018

@author: Sir Scoffield
"""

height_weight_age = [70, # inches,
170, # pounds,
40 ] # years
grades = [95, # exam1
80, # exam2
75, # exam3
62 ] # exam4
A = [[1, 2, 3], # A has 2 rows and 3 columns
[4, 5, 6]]
B = [[1, 2], # B has 3 rows and 2 columns
[3, 4],
[5, 6]]
#### sttistics
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import sys
from collections import Counter
