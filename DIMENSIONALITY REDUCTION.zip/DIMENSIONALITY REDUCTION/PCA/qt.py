# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 16:33:17 2018

@author: Sir Scoffield
"""

# area variables (in square meters)
hall = 11.25
kit = 18.0
liv = 20.0
bed = 10.75
bath = 9.50

# house information as list of lists
house = [["hallway", hall],
         ["kitchen", kit],
         ["living room", liv]
         ["bedroom", bed]
         ["bathroom", bath]]