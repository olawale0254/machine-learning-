# -*- coding: utf-8 -*-
"""
Created on Tue Sep  4 11:16:31 2018

@author: Sir Scoffield
"""

import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
df = pd.read_csv('malaria_predictionFINAL')